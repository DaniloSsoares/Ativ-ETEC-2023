<?php
session_start(); // Inicia a sessão

if (!isset($_SESSION["Login"])) {
    header("Location: login.php"); // Redireciona para a página de login se o usuário não estiver autenticado
    exit();
}

$login = $_SESSION["Login"];
?>

<!DOCTYPE html> 
<html>
    <head>
        <meta charset="utf-8">
        <title> Autoria-BD</title>
        <link rel="stylesheet" type="text/css" href="../css/css.css">
        <link rel="stylesheet" type="text/css" href="../css/Menu.css">
        <link rel="stylesheet" type="text/css" href="../css/carrosel.css">
        <link rel="stylesheet" type="text/css" href="../css/Sobre.css">
        <link href="https://fonts.googleapis.com/css?family=Chicle" rel="stylesheet">
    

    </head>
    <body>

       <header>
        <input type="checkbox" id="menu-bar">
        <label for="menu-bar">Menu</label>
        
        <div class="nav">
            
            <div class="menu">
                
                <nav>
                    
                    <a href="#" class="logo" >Bem-vindo:  <?php echo $login; ?></a>
                    <ul>

                        <li><a href="#">Cadastrar</a>
                            <ul>
                                <li><a href="cadastrar.php">Cadastrar Autor</a></li>
                                <li><a href="cadastrar2.php">Cadastrar Autoria</a></li>
                                <li><a href="cadastrar3.php">Cadastrar Livro</a></li>
                            </ul>
                        </li>
                    <li><a href="#">Listar</a>
                        
                            <ul>
                                <li><a href="listar.php">Listar Autor</a></li>
                                <li><a href="listar2.php">Listar Autoria</a></li>
                                <li><a href="listar3.php">Listar Livro</a></li>
                            </ul>
                        </li></li>
                  
                        <li><a href="#">Pesquisar</a>
                            <ul>
                                <li><a href="pesquisar.php">Pesquisar Autor</a></li>
                                   <li> <a href="pesquisar2.php">Pesquisar Autoria</a></li>
                                   <li> <a href="pesquisar3.php">Pesquisar Livro</a></li>
                            </ul>
                        </li></li>
                    <li><a href="#">Excluir</a>
                        
                            <ul>
                                <li><a href="excluir.php">Excluir Autor</a></li>
                                <li><a href="excluir2.php">Excluir Autoria</a></li>
                                <li><a href="excluir3.php">Excluir Livro</a></li>
                            </ul>
                        </li></li>
                        <li><a href="#">Altetar</a>
                        
                            <ul>
                                <li><a href="Alterar-Autor.php">Alterar Autor</a></li>
                                <li><a href="Alterar-Autoria.php">Alterar Autoria</a></li>
                                <li><a href="Alterar-Livro.php">Alterar Livro</a></li>
                            </ul>
                        </li></li>
                </ul>
                </nav>
            </div>
        </div>
       </header> 
       <!---->
       <div class="pic-ctn">
        <img src="https://i.pinimg.com/originals/3c/7a/fc/3c7afc1b68c0f8cc367dd9d0f1f383de.jpg?t=1" alt="" class="pic">
        <img src="https://images3.alphacoders.com/132/1322308.jpeg?t=2" alt="" class="pic">
        <img src="https://cdn.wallpapersafari.com/70/43/Pu3aLo.jpg?t=3" alt="" class="pic">
        <img src="https://images3.alphacoders.com/132/1329414.png?t=4" alt="" class="pic">
        <img src="https://wallpaper-house.com/data/out/9/wallpaper2you_358925.jpg?t=5" alt="" class="pic">
      </div>

        <div class="container">
            <div class="card">
                <div class="content">
                    <h2>01</h2>
                    <h3>Cadastrar  </h3>
                    <p>Cadastre  aqui!</p>
                         <a href="cadastrar.php">Cadastrar Autor </a>
                         <a href="cadastrar2.php">Cadastrar Autoria </a>
                         <a href="cadastrar3.php">Cadastrar Livros</a>
                        
                </div>
            </div>
                <div class="card">
                    <div class="content">
                        <h2>02</h2>
                        <h3>Listar</h3>
                        <p>Veja ... aqui!</p>

                        <a href="listar.php">Autor</a>
                        <a href="listar2.php">Autoria</a>
                        <a href="listar3.php">Livros</a>
                        
        </div>
        </div>
        <div class="card">
            <div class="content">
                <h2>03</h2>
                <h3>Pesquisar</h3>
                <p>Pesquise... aqui!</p>
                       <a href="pesquisar.php">Pesquisar Autor</a>
                       <a href="pesquisar2.php">Pesquisar Autoria</a>
                       <a href="pesquisar3.php">Pesquisar Livro</a>
                      

                    </div> </div>

                    <div class="card">
                        <div class="content">
                            <h2>04</h2>
                            <h3>Excluir</h3>
                            <p>Excluir...</p>
                                   <a href="excluir.php">Excluir Autor</a>
                                   <a href="excluir2.php">Excluir Autoria</a>
                                   <a href="excluir3.php">Excluir Livro</a>
                                
            
                                </div> </div>
                                <div class="card">
                                    <div class="content">
                                        <h2>05</h2>
                                        <h3>Alterar</h3>
                                        <p>Alterar...  aqui!</p>
                                               <a href="Alterar-Autor.php">Alterar Autor</a>
                                               <a href="Alterar-Autoria.php">Alterar Autoria</a>
                                               <a href="Alterar-Livro.php">Alterar Livro</a>
                                               
                                            </div> </div>
                    
                    
                                            <body>
   

    <h1 class="rev-block">
        <span>Etec Zona Leste</span>
      </h1>
      <h1 class="rev-block onemore">
        <span>realizado por:</span><br>
        <span>Danilo Santos Soares</span>
      </h1>
                    <script src="../javascript/carrosel.js"></script>
                    <script type="text/javascript" src="vanilla-tilt.js"></script>
                    <script>
                     VanillaTilt.init(document.querySelectorAll(".card"),{
                        max:25,
                        speed:400,
                        glare:true,
                        "max-glare":1,
                    });
                    </script>

    
    </body>
</html>