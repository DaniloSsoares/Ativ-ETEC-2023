<?php

include_once 'conectar.php';

//parte 1 - atributos
error_reporting(E_ALL);
ini_set('display_errors', 1);

function Erro() {
    echo '<script>window.location.href = "erro.php";</script>';
    exit();
}
class Autoria
{
     
    private $Cod_Autor;
    private $NomeAutor;
    private $Sobrenome;
    private $Email;
    private $Nasc;
    private $conn;

    //parte 2 os getters e setter
    public function getCod_Autor(){
        return $this->cod_autor;
    }
    public function setCod_Autor($ccod_autor){
        $this->cod_autor = $ccod_autor;
    }

    public function getNomeAutor(){
        return $this->nome;
    }
    public function setNomeAutor($name){
    $this->nome= $name;
    }
    public function getSobrenome(){
        return $this->sobreNome;
    }
       public function setSobrenome($Ssobrenome){
        $this->sobreNome=$Ssobrenome;
    }

    public function getEmail(){
        return $this->email;
    }
       public function setEmail($EEmail){
        $this->email=$EEmail;
    }

    public function getNasc(){
        return $this->nasc;
    }
       public function setNasc($NNasc){
        $this->nasc=$NNasc;
    }

function listar()
{
    try{

        $this->conn = new conectar();
        $sql = $this->conn->query("select * from autor order by Cod_Autor");
        $sql -> execute();
        return $sql->fetchAll();
        $this->conn = null;
    }
    catch(PDOException $exc)
    {
        echo "Erro ao executar consulta. " . $exc->getMessage();
    }
}
function salvar()
{  
    try {
        $this->conn = new Conectar();
        $sql = $this->conn->prepare("insert into autor values (null,?,?,?,?)");
        @$sql->bindParam(1, $this->getNomeAutor(), PDO::PARAM_STR);
        @$sql->bindParam(2, $this->getSobrenome(), PDO::PARAM_STR);
        @$sql->bindParam(3, $this->getEmail(), PDO::PARAM_STR);
        @$sql->bindParam(4, $this->getNasc(), PDO::PARAM_STR);
        if ($sql->execute() == 1) {
            return "Registro salvo com sucesso!";
        }
        $this->conn = null;
    } catch (PDOException $exc) {
        echo "Erro ao Salvar o registro." . $exc->getMessage();
    }
}
 //Parte alterar
    
 function alterar(){
    try{
        $this-> conn = new Conectar();
        $sql = $this -> conn ->prepare("select * from autor where Cod_Autor = ?"); //informe o ? (parametro)
        @$sql -> bindParam(1,$this->getCod_Autor(),PDO::PARAM_STR);
        @$sql->execute();

        $result = $sql->fetchAll();
            $this ->conn = null;
            
            $dbCodAutor = $result[0]['Cod_Autor']; // Assumindo que o campo do banco de dados seja 'Cod_Autor'
            if ($dbCodAutor !== $this->getCod_Autor()) {
                // Redirecionar para erro.php se os códigos de autor não coincidirem
                header("Location: erro.php");
                exit();
            }
            return $result;
        }
    
    catch(PDOException $exc)
    {
        echo "Erro ao alterar." . $exc->getMessage();
    }
 }

 function alterar2(){
    try{
    $this-> conn = new Conectar();
    $sql = $this -> conn ->prepare("update autor set NomeAutor =?, Sobrenome = ?, Email = ?, Nasc = ? where Cod_Autor = ?");
    @$sql -> bindParam(1,$this->getNomeAutor(),PDO::PARAM_STR);
    @$sql->bindParam(2, $this->getSobrenome(),PDO::PARAM_STR);
    @$sql->bindParam(3, $this->getEmail(),PDO::PARAM_STR);
    @$sql->bindParam(4, $this->getNasc(),PDO::PARAM_STR);
    @$sql->bindParam(5, $this->getCod_Autor(),PDO::PARAM_STR);
    if($sql->execute()==1)
    {
        return "Registro alterado com sucesso!";
    }
    $this->conn = null;
 }  
  catch(PDOException $exc)
 {
     echo "Erro ao Salvar o registro." . $exc->getMessage();
 }
}

function consultar()
{
    try{
        $this->conn = new Conectar();
        $sql = $this->conn->prepare("select * from autor where NomeAutor like ?");
        @$sql-> bindParam(1, $this->getNomeAutor(),PDO::PARAM_STR);
        @$sql -> execute();
        $result= $sql->fetchAll();
        if (!$result) {
            return "Nome não encontrado, tente novamente";
        }
        else{
            $this->conn = null;
            return $result;
        }
        

}
catch(PDOException $exc)
    {
        echo "Erro ao Executar Consulta.." . $exc->getMessage();
    }
}


function exclusao()
{
   try
   {
       $this-> conn = new Conectar();
      
        // Verificar se o código de autor existe antes de excluir
        $sql = $this->conn->prepare("SELECT * FROM autor WHERE Cod_Autor = ?");
        @$sql->bindParam(1, $this->getCod_Autor(), PDO::PARAM_STR);
        $sql->execute();

        $result = $sql->fetch(PDO::FETCH_ASSOC);

        if (!$result) {
            // Redirecionar para erro.php se o código de autor não existir
            Erro();
        }
        $sql = $this -> conn ->prepare("delete from autor where Cod_Autor = ?"); //informe o ? (parametro)
        @$sql -> bindParam(1,$this->getCod_Autor(),PDO::PARAM_STR);
        if($sql->execute() == 1)
        {
            return "Excluindo com sucesso! ";
        }
        else
        {
            return "Erro na exclusão !";
        }
    
            $this ->conn = null;
        }
    
    catch(PDOException $exc)
    {
        echo "Erro ao excluir" . $exc->getMessage();
    }
      }

}


class Autoria2
{
    private $Cod_autor;
    private $Cod_Livro;
    private $DataLancamento;
    private $Editora;
    private $conn;

    public function getCod_autor()
    {
        return $this->cod_Autor;
    }

    public function setCod_Autor($ccod_autor)
    {
        $this->cod_Autor = $ccod_autor;
    }

    public function getCod_Livro()
    {
        return $this->cod_livro;
    }

    public function setCod_Livro($ccod_livro)
    {
        $this->cod_livro = $ccod_livro;
    }

    public function getDataLancamento()
    {
        return $this->DataLanc;
    }

    public function setDataLancamento($DDataLanacamento)
    {
        $this->DataLanc = $DDataLanacamento;
    }

    public function getEditora()
    {
        return $this->Edit;
    }

    public function setEditora($EEditora)
    {
        $this->Edit = $EEditora;
    }

    function listar2()
    {
        try {
            $this->conn = new conectar();
            $sql = $this->conn->query("select * from autoria order by Cod_autor");
            $sql->execute();
            return $sql->fetchAll();
            $this->conn = null;
        } catch (PDOException $exc) {
            echo "Erro ao executar consulta. " . $exc->getMessage();
        }
    }

    function salvar()
    {
        try{
            $this->conn = new Conectar();
            $sql = $this->conn->prepare("insert into autoria values(?,?,?,?)");
            @$sql-> bindParam(1,$this->getCod_autor(),PDO::PARAM_STR);
            @$sql-> bindParam(2,$this->getCod_Livro(),PDO::PARAM_STR);
            @$sql-> bindParam(3,$this->getDataLancamento(),PDO::PARAM_STR);
            @$sql-> bindParam(4,$this->getEditora(),PDO::PARAM_STR);
            if($sql->execute() == 1)
            {
                return "Registro salvo com sucesso!";
            }
            $this->conn = null;
        }
        catch (PDOException $exc)
        {
            echo "Erro ao Salvar o registro." . $exc->getMessage();
        }
    }

    function exclusao()
 {
    try
    {
        $this-> conn = new Conectar();


 $sql = $this->conn->prepare("SELECT * FROM autoria WHERE Cod_Autor = ?");
 @$sql->bindParam(1, $this->getCod_Autor(), PDO::PARAM_STR);
 $sql->execute();

 $result = $sql->fetch(PDO::FETCH_ASSOC);

 if (!$result) {
     
     Erro();
 }

        $sql = $this -> conn ->prepare("delete from autoria where Cod_Autor = ?"); //informe o ? (parametro)
        @$sql -> bindParam(1,$this->getCod_autor(),PDO::PARAM_STR);
        if($sql->execute() == 1)
        {
            return "Excluindo com sucesso! ";
        }
        else
        {
            return "Erro na exclusão !";
        }
    
            $this ->conn = null;
        }
    
    catch(PDOException $exc)
    {
        echo "Erro ao excluir" . $exc->getMessage();
    }
      }

      function alterar(){
        try{
            $this-> conn = new Conectar();
            $sql = $this -> conn ->prepare("select * from autoria where Cod_Autor =?"); //informe o? (parametro)
            @$sql -> bindParam(1,$this->getCod_autor(),PDO::PARAM_STR);
            @$sql->execute();

                         
        $result= $sql->fetchAll();
        $this ->conn = null;
        if (!$result) {
            // Se nenhum resultado for encontrado, retornar um array vazio
            header("Location: erro.php");
        } else {
            // Se houver resultados, retornar o array
            return $result;
        }}
        
    
    catch(PDOException $exc)
    {
        echo "Erro ao alterar." . $exc->getMessage();
    }
 }

function alterar2(){
    try{
        $this-> conn = new Conectar();
        $sql = $this -> conn ->prepare("update autoria set Cod_Livro =?, DataLancamento =?, Editora =? where Cod_autor =?");
        @$sql -> bindParam(1,$this->getCod_Livro(),PDO::PARAM_STR);
        @$sql->bindParam(2, $this->getDataLancamento(),PDO::PARAM_STR);
        @$sql->bindParam(3, $this->getEditora(),PDO::PARAM_STR);
        @$sql->bindParam(4, $this->getCod_autor(),PDO::PARAM_STR);
        if($sql->execute()==1)
        {
            return "Registro alterado com sucesso!";
        }
        $this->conn = null;
     }  
      catch(PDOException $exc)
     {
         echo "Erro ao Salvar o registro." . $exc->getMessage();
     }
    }


      function consultar(){
        try{

        
      $this -> conn = new Conectar();
       $sql= $this-> conn ->prepare('select * from autoria where  Cod_Autor like ? ');

     @$sql -> bindParam(1,$this->getCod_Autor(),PDO::PARAM_STR);
     @$sql ->execute();
     $result=  $sql -> fetchAll();  
      if (!$result) {
        return "Código não encontrado, tente novamente";
    }
    else{
        $this->conn = null;
        return $result;
    }
    

}
catch(PDOException $exc)
{
    echo "Erro ao Executar Consulta.." . $exc->getMessage();
}
}
}

class Autoria3{
  
     private  $Cod_Livro;
     private $Tiíulo;
     Private $Categoria;
     private $ISBN;
     private $Idioma;
     private $Qtdepag;
     private $conn;

     public function getCod_Livro(){
        return $this-> cod_Livro;
     }
     public function setCod_Livro($CCod_Livro){
        $this->cod_Livro = $CCod_Livro;
     }
     public function getTitulo(){
        return $this-> tiíulo;
     }
     public function setTitulo($TTiíulo){
        $this->tiíulo = $TTiíulo;
     }
     public function getCategoria(){
        return $this-> categoria;
     }
     public function setCategoria($CCategoria){
        $this->categoria = $CCategoria;
     }
     public function getISBN(){
        return $this-> isbn;
     }
     public function setISBN($IISBN){
        $this->isbn = $IISBN;
     }
     public function getIdioma(){
        return $this-> idioma;
     }
     public function setIdioma($IIdioma){
        $this->idioma = $IIdioma;
     }
     public function getQtdepag(){
        return $this-> qtdepag;
     }
     public function setQtdepag($QQtdepag){
        $this->qtdepag = $QQtdepag;
     }
     function listar3()
     {
         try {
             $this->conn = new conectar();
             $sql = $this->conn->query("select * from livro where  Cod_Livro ");
             $sql->execute();
             return $sql->fetchAll();
             $this->conn = null;
         } catch (PDOException $exc) {
             echo "Erro ao executar consulta. " . $exc->getMessage();
         }
     }
    
     //Parte Salvar
    function salvar()
    {  
        try {
            $this->conn = new Conectar();
            $sql = $this->conn->prepare("insert into livro values (null,?,?,?,?,?)");
            @$sql->bindParam(1, $this->getTitulo(), PDO::PARAM_STR);
            @$sql->bindParam(2, $this->getCategoria(), PDO::PARAM_STR);
            @$sql->bindParam(3, $this->getISBN(), PDO::PARAM_STR);
            @$sql->bindParam(4, $this->getIdioma(), PDO::PARAM_STR);
            @$sql->bindParam(5, $this->getQtdepag(), PDO::PARAM_STR);
            if ($sql->execute() == 1) {
                return "Registro salvo com sucesso!";
            }
            $this->conn = null;
        } catch (PDOException $exc) {
            echo "Erro ao Salvar o registro." . $exc->getMessage();
        }
    }

    function exclusao()
    {
       try
       {
           $this-> conn = new Conectar();

 $sql = $this->conn->prepare("SELECT * FROM livro where Cod_Livro = ?");
 @$sql->bindParam(1, $this->getCod_Livro(), PDO::PARAM_STR);
 $sql->execute();

 $result = $sql->fetch(PDO::FETCH_ASSOC);

 if (!$result) {
  
     Erro();
 }

           $sql = $this -> conn ->prepare("delete from livro where Cod_Livro = ?"); //informe o ? (parametro)
           @$sql -> bindParam(1,$this-> getCod_Livro(),PDO::PARAM_STR);
           if($sql->execute() == 1)
           {
               return "Excluindo com sucesso! ";
           }
           else
           {
               return "Erro na exclusão !";
           }
       
               $this ->conn = null;
           }
       
       catch(PDOException $exc)
       {
           echo "Erro ao excluir" . $exc->getMessage();
       }
         }
      function consultar(){
        try{

        
      $this -> conn = new Conectar();
       $sql= $this-> conn ->prepare('select * from livro where Cod_Livro like ? ');
       @$sql -> bindParam(1,$this-> getCod_Livro(),PDO::PARAM_STR);
       @$sql ->execute();
       $result = $sql -> fetchAll();
       if (!$result) {
        return "Código não encontrado, tente novamente";
    }
    else{
        $this->conn = null;
        return $result;
    }
    

}
catch(PDOException $exc)
{
    echo "Erro ao Executar Consulta.." . $exc->getMessage();
}
}
        

     //Parte alterar
    function alterar(){
        try{
            $this-> conn = new Conectar();
            $sql = $this -> conn ->prepare("select * from livro where Cod_Livro =?"); //informe o? (parametro)
            @$sql -> bindParam(1,$this-> getCod_Livro(),PDO::PARAM_STR);
            @$sql->execute();

            $result = $sql->fetchAll();
            $this ->conn = null;

            $dbCodLivro = $result[0]['Cod_Livro']; // Assumindo que o campo do banco de dados seja 'Cod_Autor'
            if ($dbCodLivro !== $this->getCod_Livro()) {
                // Redirecionar para erro.php se os códigos de autor não coincidirem
                header("Location: erro.php");
                exit();
            }
            return $result;
        }
    
    catch(PDOException $exc)
    {
        echo "Erro ao alterar." . $exc->getMessage();
    }
 }

 function alterar2(){
try{
    $this->conn = new Conectar();
    $sql = $this -> conn ->prepare("update livro set Tiíulo =?, Categoria =?, ISBN =?, Idioma =?, Qtdepag =? where Cod_Livro =?");
    @$sql -> bindParam(1,$this-> getTitulo(),PDO::PARAM_STR);
    @$sql->bindParam(2, $this->getCategoria(),PDO::PARAM_STR);
    @$sql->bindParam(3, $this->getISBN(),PDO::PARAM_STR);
    @$sql->bindParam(4, $this->getIdioma(),PDO::PARAM_STR);
    @$sql->bindParam(5, $this->getQtdepag(),PDO::PARAM_STR);
    @$sql->bindParam(6, $this->getCod_Livro(),PDO::PARAM_STR);
    if($sql->execute()==1)
    {
        return "Registro alterado com sucesso!";
    }
    $this->conn = null;
    }   catch(PDOException $exc)
    {
        echo "Erro ao Salvar o registro.". $exc->getMessage();
    }

}
 

    }
