<?php
session_start(); // Inicia a sessão

if (!isset($_SESSION["Login"])) {
    header("Location: login.php"); // Redireciona para a página de login se o usuário não estiver autenticado
    exit();
}

$login = $_SESSION["Login"];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/css3.css">
    <link rel="stylesheet" type="text/css" href="../css/Menu.css">
    <title>Excluir</title>
    
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.11/jquery.mask.min.js"></script>
</head>
<body>
<header>
        <input type="checkbox" id="menu-bar">
        <label for="menu-bar">Menu</label>
        
        <div class="nav">
            
            <div class="menu">
                
                <nav>
                    <a href="Home.php" class="logo">Home</a>
                  
                    <ul>

                    <li><a href="#">Bem-vindo, <?php echo $login; ?></a></li>

                        <li><a href="#">Cadastrar</a>
                            <ul>
                                <li><a href="cadastrar.php">Cadastrar Autor</a></li>
                                <li><a href="cadastrar2.php">Cadastrar Autoria</a></li>
                                <li><a href="cadastrar3.php">Cadastrar Livro</a></li>
                            </ul>
                        </li>
                    <li><a href="#">Listar</a>
                        
                            <ul>
                                <li><a href="listar.php">Listar Autor</a></li>
                                <li><a href="listar2.php">Listar Autoria</a></li>
                                <li><a href="listar3.php">Listar Livro</a></li>
                            </ul>
                        </li></li>
                  
                        <li><a href="#">Pesquisar</a>
                            <ul>
                                <li><a href="pesquisar.php">Pesquisar Autor</a></li>
                                   <li> <a href="pesquisar2.php">Pesquisar Autoria</a></li>
                                   <li> <a href="pesquisar3.php">Pesquisar Livro</a></li>
                            </ul>
                        </li></li>
                    <li><a href="#">Excluir</a>
                        
                            <ul>
                                <li><a href="excluir.php">Excluir Autor</a></li>
                                <li><a href="excluir2.php">Excluir Autoria</a></li>
                                <li><a href="excluir3.php">Excluir Livro</a></li>
                            </ul>
                        </li></li>
                        <li><a href="#">Altetar</a>
                        
                            <ul>
                                <li><a href="Alterar-Autor.php">Alterar Autor</a></li>
                                <li><a href="Alterar-Autoria.php">Alterar Autoria</a></li>
                                <li><a href="Alterar-Livro.php">Alterar Livro</a></li>
                            </ul>
                        </li></li>
                        
                </ul>
                </nav>
            </div>
        </div>
       </header> 

      
<div class="logreg-box">
            <div class="caixa-Login">
                <form name ="cliente" action="" method="POST">
                    <h2>Excluir Autor</h2>
        
                    <div class="input-box">
                        <span class="icon"><box-icon name='envelope' type='solid'></box-icon></span>
                        <input id="id" name = "txtid" type="text"  required > </input> 
                        <label>Id do Autor:</label>
                    </div>

                  
        
                   <input type="submit" name="btn_excluir_autoria" value="Excluir Autoria" class="btn">
                 

                   <div class="btn1"><button type="button" class="btn" onclick="limparCampos()">
                <a href="#"> Limpar</a></button>
                </div>
                  
                <div class="btn2"><button type="button" class="btn">
                <a href="Home.php">Voltar</a></button>
                </div>
                    
                </form>
            </div>


        <?php 
       extract($_POST,EXTR_OVERWRITE);
       if(isset($btn_excluir_autoria)&& !empty($txtid))
       {
           include_once 'autoria.php';
           $p = new Autoria();
           $p->setCod_Autor($txtid);
           echo "<h3>" . $p->exclusao() . "<h3>"; //chamada de método - o $p é parametro enviado
       }
       
        ?>

        

        <script>
    function limparCampos() {
    document.getElementById('id').value = '';
     }
</script>
<script>
        $(document).ready(function() {
            $('#id').on('keypress', function(event) {
                $('#id').mask('000000');
                if (event.which < 48 || event.which > 57) {
                    event.preventDefault();
                }
            });
        });
        </script>

        </fieldset>
</body>
</html>