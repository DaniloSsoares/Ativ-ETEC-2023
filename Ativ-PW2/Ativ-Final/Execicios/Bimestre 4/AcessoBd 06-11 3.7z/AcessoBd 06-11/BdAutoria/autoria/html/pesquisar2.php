<?php
session_start(); // Inicia a sessão

if (!isset($_SESSION["Login"])) {
    header("Location: login.php"); // Redireciona para a página de login se o usuário não estiver autenticado
    exit();
}

$login = $_SESSION["Login"];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/css3.css">
    <link rel="stylesheet" type="text/css" href="../css/tabela.css">
    <link rel="stylesheet" type="text/css" href="../css/Menu.css">
    <title>Pesquisa</title>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.11/jquery.mask.min.js"></script>
</head>

<body>
    <header>
        <input type="checkbox" id="menu-bar">
        <label for="menu-bar">Menu</label>

        <div class="nav">

            <div class="menu">

                <nav>
                    <a href="Home.php" class="logo">Home</a>

                    <ul>

                        <li><a href="#">Bem-vindo, <?php echo $login; ?></a></li>

                        <li><a href="#">Cadastrar</a>
                            <ul>
                                <li><a href="cadastrar.php">Cadastrar Autor</a></li>
                                <li><a href="cadastrar2.php">Cadastrar Autoria</a></li>
                                <li><a href="cadastrar3.php">Cadastrar Livro</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Listar</a>

                            <ul>
                                <li><a href="listar.php">Listar Autor</a></li>
                                <li><a href="listar2.php">Listar Autoria</a></li>
                                <li><a href="listar3.php">Listar Livro</a></li>
                            </ul>
                        </li>
                        </li>

                        <li><a href="#">Pesquisar</a>
                            <ul>
                                <li><a href="pesquisar.php">Pesquisar Autor</a></li>
                                <li> <a href="pesquisar2.php">Pesquisar Autoria</a></li>
                                <li> <a href="pesquisar3.php">Pesquisar Livro</a></li>
                            </ul>
                        </li>
                        </li>
                        <li><a href="#">Excluir</a>

                            <ul>
                                <li><a href="excluir.php">Excluir Autor</a></li>
                                <li><a href="excluir2.php">Excluir Autoria</a></li>
                                <li><a href="excluir3.php">Excluir Livro</a></li>
                            </ul>
                        </li>
                        </li>
                        <li><a href="#">Altetar</a>

                            <ul>
                                <li><a href="Alterar-Autor.php">Alterar Autor</a></li>
                                <li><a href="Alterar-Autoria.php">Alterar Autoria</a></li>
                                <li><a href="Alterar-Livro.php">Alterar Livro</a></li>
                            </ul>
                        </li>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
    </header>


    <div class="logreg-box">
        <div class="caixa-Login">
            <form action="" name="cliente" method="POST">
                <h2>Pesquisar </h2>

                <div class="input-box">
                    <span class="icon"><box-icon name='envelope' type='solid'></box-icon></span>
                    <input id="pesquisa" type="text" name="txtnome" required>
                    <Label>Pesquisar:(Cod_Autor)</Label>
                </div>

                <button name="btnpesquisar" type="submit" class="btn" value="cadastrar">Pesquisar</button>

                <div class="btn1"><button type="button" class="btn" onclick="limparCampos()">
                        <a href="#"> Limpar</a></button>
                </div>

                <div class="btn2"><button type="button" class="btn">
                        <a href="Home.php">Voltar</a></button>
                </div>

            </form>

        </div>
    </div>

    <div class="box">
        <fieldset>
            <table class="product-table">
                <thead>
                    <h3> Pesquisar Autor</h3>
                    <tr>
                        <th>Cod_Autor</th>
                        <th>Cod_Livror</th>
                        <th>Data Lançamento</th>
                        <th>Editora</th>


                    </tr>
                </thead>
                <tbody>
                    <?php
                    error_reporting(E_ALL);
                    ini_set('display_errors', 1);


                    if (isset($_POST['btnpesquisar'])) {
                        include_once 'autoria.php';
                        $p = new Autoria2();
                        $p->setCod_Autor($_POST['txtnome'] . '%'); // Concatenando '%' para busca aproximada
                        $pro_bd = $p->consultar(); // Chamada do método com retorno

                        if (is_string($pro_bd)) {
                            // Exibir a mensagem
                            echo "<h2><p>$pro_bd</p></h2>";
                        } else {
                            foreach ($pro_bd as $pro_mostrar) {
                                echo "<tr>";
                                echo "<td>Cod_autor: " . $pro_mostrar[0] . "</td>"; //como matriz - posição 0
                                echo "<td>Cod_Livro: " . $pro_mostrar[1] . "</td>"; //como matriz - posição 1
                                echo "<td>DataLancamento: " . $pro_mostrar[2] . "</td>"; //como matriz - posição 2
                                echo "<td>Editora: " . $pro_mostrar[3] . "</td>"; //como matriz - posição 3
                                echo "</tr>";
                            }
                        }
                    }
                    ?>

            </table>
    </div>
    </div>
    </fieldset>


    <script>
        function limparCampos() {
            document.getElementById('pesquisa').value = '';
        }
    </script>


    <script>
        $(document).ready(function() {
            $('#pesquisa').on('keypress', function(event) {
                $('#pesquisa').mask('000000');
                // Bloquear números (códigos de 48 a 57)
                if (event.which < 48 || event.which > 57) {
                    event.preventDefault();
                }
            });
        });
    </script>
</body>

</html>