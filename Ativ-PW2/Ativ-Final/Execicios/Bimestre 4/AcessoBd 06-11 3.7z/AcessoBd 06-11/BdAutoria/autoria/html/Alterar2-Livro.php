<?php
session_start(); // Inicia a sessão

if (!isset($_SESSION["Login"])) {
    header("Location: login.php"); // Redireciona para a página de login se o usuário não estiver autenticado
    exit();
}

$login = $_SESSION["Login"];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/css4.css">
    <link rel="stylesheet" type="text/css" href="../css/Menu.css">
    <title>Alterar</title>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.11/jquery.mask.min.js"></script>

</head>
<body>
<header>
        <input type="checkbox" id="menu-bar">
        <label for="menu-bar">Menu</label>
        
        <div class="nav">
            
            <div class="menu">
                
                <nav>
                    <a href="index.html" class="logo">Home</a>
                  
                    <ul>

                    <li><a href="#">Bem-vindo, <?php echo $login; ?></a></li>

                        <li><a href="#">Cadastrar</a>
                            <ul>
                                <li><a href="cadastrar.php">Cadastrar Autor</a></li>
                                <li><a href="cadastrar2.php">Cadastrar Autoria</a></li>
                                <li><a href="cadastrar3.php">Cadastrar Livro</a></li>
                            </ul>
                        </li>
                    <li><a href="#">Listar</a>
                        
                            <ul>
                                <li><a href="listar.php">Listar Autor</a></li>
                                <li><a href="listar2.php">Listar Autoria</a></li>
                                <li><a href="listar3.php">Listar Livro</a></li>
                            </ul>
                        </li></li>
                  
                        <li><a href="#">Pesquisar</a>
                            <ul>
                                <li><a href="pesquisar.php">Pesquisar Autor</a></li>
                                   <li> <a href="pesquisar2.php">Pesquisar Autoria</a></li>
                                   <li> <a href="pesquisar3.php">Pesquisar Livro</a></li>
                            </ul>
                        </li></li>
                    <li><a href="#">Excluir</a>
                        
                            <ul>
                                <li><a href="excluir.php">Excluir Autor</a></li>
                                <li><a href="excluir2.php">Excluir Autoria</a></li>
                                <li><a href="excluir3.php">Excluir Livro</a></li>
                            </ul>
                        </li></li>
                        <li><a href="#">Altetar</a>
                        
                            <ul>
                                <li><a href="Alterar-Autor.php">Alterar Autor</a></li>
                                <li><a href="Alterar-Autoria.php">Alterar Autoria</a></li>
                                <li><a href="Alterar-Livro.php">Alterar Livro</a></li>
                            </ul>
                        </li></li>
                </ul>
                </nav>
            </div>
        </div>
       </header> 

<?php 
$txtLivro= $_POST["txtLivro"];
include_once 'autoria.php';
$p = new Autoria3();
$p->setCod_Livro($txtLivro);
$pro_bd=$p->alterar();
?>

<div class="logreg-box">
    <div class="caixa-Login">
    <form name="cliente" action="" method="POST">
        <h2>Alterar</h2>

   <?php
   foreach($pro_bd as $pro_mostrar){
   ?>
   
    <input type="hidden" name="txtLivro" value='<?php echo $pro_mostrar[0]?>'>
    <?php echo"ID: ". $pro_mostrar[0];?>

    <div class="input-box">
        <input id="Tit" type="text"  name="txtTitulo" value='<?php echo $pro_mostrar[1]?>'required>
        <label>Titulo:</label>
        </div>

        <div class="input-box">
        <input type="text" id="Cat" name="txtCategoria" value='<?php echo $pro_mostrar[2]?>' required>
        <label>Categoria:</label>

        </div>
        <div class="input-box">
            <input type="text" id="ISBN" name="txtISBN" value='<?php echo $pro_mostrar[3]?>' required>
            <label>ISBN:</label>
        
            </div>
        <div class="input-box">
            <input type="text" id="Idi" name="txtIdioma" value='<?php echo $pro_mostrar[4]?>' required>
            <label>Idioma:</label>
            </div>

        <div class="input-box">
            <input type="text" id="Quan" name="txtPaginas" value='<?php echo $pro_mostrar[5]?>' required>
            <label>Quantidade de Páginas:</label>
            </div>
        
            <button  name="btnalterar" type="submit" class="btn" value ="Alterar">Alterar</button>

            <div class="btn1"><button type="button" class="btn" onclick="limparCampos()">
            <a href="#"> Limpar</a></button> </div>
                        
                    <div class="btn2"><button type="button" class="btn">
                    <a href="Alterar-Livro.php">Voltar</a></button>
                    </div>
                        
                    </form>
      </div>

        <?php 
        }
        extract($_POST, EXTR_OVERWRITE);
        if(isset($btnalterar)){
            include_once'autoria.php';
            $pro = new Autoria3();
            $pro->setTitulo($txtTitulo);
            $pro->setCategoria($txtCategoria);
            $pro->setISBN($txtISBN);
            $pro->setIdioma($txtIdioma);
            $pro->setQtdepag($txtPaginas);
            $pro->setCod_Livro($txtLivro);

            echo "<br><br><h3>". $pro->alterar2();
           
            
    echo '<script>
    setTimeout(function(){
       window.location.href = "Alterar-Livro.php";
    }, 1000); 
  </script>';

        }
        ?>

       <script>
         function limparCampos() {
         document.getElementById('Tit').value = '';
         document.getElementById('Cat').value = '';
         document.getElementById('ISBN').value = '';
         document.getElementById('Idi').value = '';
         document.getElementById('Quan').value = '';
         }
         </script>
         
         
<script>
    $(document).ready(function(){
        $('#Tit').on('keypress', function(event){
            if (event.which >= 48 && event.which <= 57) {
                event.preventDefault();
            }
        });
        $('#Cat').on('keypress', function(event){
            if (event.which >= 48 && event.which <= 57) {
                event.preventDefault()
                
            }
           
        });
    });
        $('#ISBN').on('keypress', function(event){
            $('#ISBN').mask('000-00-00000-00-0');
            if (event.which < 48 || event.which > 57) {
                event.preventDefault()
                
            }
           
        });
  
        $('#Idi').on('keypress', function(event){
            if (event.which >= 48 && event.which <= 57) {
                event.preventDefault()
                
            }
           
        });
    
        $('#Quan').on('keypress', function(event){
            $('#Quan').mask('00000');
            if (event.which < 48 || event.which > 57) {
                event.preventDefault()
                
            }
           
        });
   
</script>
</script>
</body>
</html>