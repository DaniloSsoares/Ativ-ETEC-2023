<?php
session_start(); // Inicia a sessão

if (!isset($_SESSION["Login"])) {
    header("Location: login.php"); // Redireciona para a página de login se o usuário não estiver autenticado
    exit();
}

$login = $_SESSION["Login"];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Erro</title>
    <link rel="stylesheet" type="text/css" href="../css/erro.css">
    <link rel="stylesheet" type="text/css" href="../css/Menu.css">
    <title>Cadastrar</title>
</head>
<body>
<header>
        <input type="checkbox" id="menu-bar">
        <label for="menu-bar">Menu</label>
        
        <div class="nav">
            
            <div class="menu">
                
                <nav>
                    <a href="index.html" class="logo">Home</a>
                  
                    <ul>

                    <li><a href="#">Bem-vindo, <?php echo $login; ?></a></li>

                        <li><a href="#">Cadastrar</a>
                            <ul>
                                <li><a href="cadastrar.php">Cadastrar Autor</a></li>
                                <li><a href="cadastrar2.php">Cadastrar Autoria</a></li>
                                <li><a href="cadastrar3.php">Cadastrar Livro</a></li>
                            </ul>
                        </li>
                    <li><a href="#">Listar</a>
                        
                            <ul>
                                <li><a href="listar.php">Listar Autor</a></li>
                                <li><a href="listar2.php">Listar Autoria</a></li>
                                <li><a href="listar3.php">Listar Livro</a></li>
                            </ul>
                        </li></li>
                  
                        <li><a href="#">Pesquisar</a>
                            <ul>
                                <li><a href="pesquisar.php">Pesquisar Autor</a></li>
                                   <li> <a href="pesquisar2.php">Pesquisar Autoria</a></li>
                                   <li> <a href="pesquisar3.php">Pesquisar Livro</a></li>
                            </ul>
                        </li></li>
                    <li><a href="#">Excluir</a>
                        
                            <ul>
                                <li><a href="excluir.php">Excluir Autor</a></li>
                                <li><a href="excluir2.php">Excluir Autoria</a></li>
                                <li><a href="excluir3.php">Excluir Livro</a></li>
                            </ul>
                        </li></li>
                        <li><a href="#">Altetar</a>
                        
                            <ul>
                                <li><a href="Alterar-Autor.php">Alterar Autor</a></li>
                                <li><a href="Alterar-Autoria.php">Alterar Autoria</a></li>
                                <li><a href="Alterar-Livro.php">Alterar Livro</a></li>
                            </ul>
                        </li></li>
                </ul>
                </nav>
            </div>
        </div>
       </header> 

<div class="erro">
  <div class="box">
    <span></span>
    <div class="content">
      <h2>Erro</h2>
      <p>o Valor digitado não corresponde ao Codigo</p>
      <a href="Home.php">Voltar para a Home</a>
    </div>
  </div>
</body>
</html>