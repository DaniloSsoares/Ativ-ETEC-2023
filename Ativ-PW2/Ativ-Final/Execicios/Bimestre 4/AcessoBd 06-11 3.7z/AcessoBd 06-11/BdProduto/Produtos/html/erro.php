<?php
session_start(); // Inicia a sessão

if (!isset($_SESSION["Login"])) {
    header("Location: login.php"); // Redireciona para a página de login se o usuário não estiver autenticado
    exit();
}

$login = $_SESSION["Login"];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Erro</title>
    <link rel="stylesheet" type="text/css" href="../css/erro.css">
    <link rel="stylesheet" type="text/css" href="../css/Menu.css">
    <title>Cadastrar</title>
</head>

<body>
         
<header>
        <input type="checkbox" id="menu-bar">
        <label for="menu-bar">Menu</label>

        <div class="nav">

            
        <div class="menu">
                
                <nav>
                    
                    <a href="#" class="logo" >Bem-vindo:  <?php echo $login; ?></a>
                    <ul>


                    <li><a href="#">Cadastrar</a>
                            <ul>
                                <li><a href="cadastrar.php">Cadastra Produto</a></li>
                                
                            </ul>
                        </li>
                    <li><a href="#">Listar</a>
                        
                            <ul>
                                <li><a href="listar.php">Listar Produtos</a></li>
                              
                            </ul>
                        </li></li>
                  
                        <li><a href="#">Pesquisar</a>
                            <ul>
                                <li><a href="pesquisa.php">Pesquisar Produto</a></li>
                                
                            </ul>
                        </li></li>
                    <li><a href="#">Excluir</a>
                        
                            <ul>
                                <li><a href="excluir.php">Excluir Produto</a></li>
                                
                            </ul>
                        </li></li>
                        <li><a href="#">Altetar</a>
                        
                            <ul>
                                <li><a href="Alterar.php">Alterar Produto</a></li>
                                
                            </ul>
                        </li></li>
                </ul>
                </nav>
            </div>
        </div>
       </header> 

    <div class="erro">
        <div class="box">
            <span></span>
            <div class="content">
                <h2>Erro</h2>
                <p>o Valor digitado não correspondente</p>
                <a href="Home.php">Voltar para a Home</a>
            </div>
        </div>
</body>

</html>