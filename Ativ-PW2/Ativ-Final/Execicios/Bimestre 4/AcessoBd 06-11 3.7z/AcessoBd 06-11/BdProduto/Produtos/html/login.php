<?php
session_start();
include_once 'usuario.php';

$existe = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    extract($_POST, EXTR_OVERWRITE);

    if (isset($btnenviar)) {
        $u = new Usuario();
        $u->setUsu($txtnome);
        $u->setSenha($txtsenha);
        $login = $u->getUsu();
        $senha = $u->getSenha();
        $loginValido = $u->logar($login, $senha);

        
            if ($loginValido) {
                $_SESSION["Login"] = $login;
                // Login bem-sucedido, redireciona para a página de boas-vindas ou outra página do seu aplicativo
                header("Location: Home.php");
                exit();
            } else {
                // Credenciais inválidas, redireciona de volta para a página de login com uma mensagem de erro
                header("Location: erroLogin.php");
                exit();
            }
        }
    }

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/Menu.css">
    <link rel="stylesheet" type="text/css" href="../css/Login.css">

    <title>Login</title>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.11/jquery.mask.min.js"></script>
</head>

<body>

    <header>
        <input type="checkbox" id="menu-bar">
        <label for="menu-bar">Menu</label>

        <div class="nav">

            <div class="menu">

                <nav>
                    <a href="login.php" class="logo">Home</a>

                    <ul>

                        <li><a href="#">Cadastrar</a>
                            <ul>
                                <a href="login.php">Faça Login primeiro</a>

                            </ul>
                        </li>
                        </li>
                        <li><a href="#">Listar</a>

                            <ul>
                                <a href="login.php">Faça Login primeiro</a>

                            </ul>
                        </li>
                        </li>

                        <li><a href="#">Pesquisar</a>
                            <ul>
                                <li><a href="login.php">Faça Login primeiro</a>

                            </ul>
                        </li>
                        </li>
                        <li><a href="#">Excluir</a>

                            <ul>
                                <a href="login.php">Faça Login primeiro</a>

                            </ul>
                        </li>
                        </li>
                        <li><a href="#">Alterar</a>

                            <ul>
                                <a href="login.php">Faça Login primeiro</a>

                            </ul>
                        </li>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
    </header>

    <body>


        <div class="background">
            <div class="shape"></div>
            <div class="shape"></div>
        </div>

        <form method="post" action="">
            <h3>Login</h3>

            <label for="username">Usuário</label>
            <input name="txtnome" type="text" maxlength="10" placeholder="Digte seu usuario " id="username" required>

            <label for="password">Senha</label>
            <input name="txtsenha" type="password" placeholder="Senha" id="password" required maxlength="3">

            <button name="btnenviar" type="submit" class="btn" value="cadastrar">Logar</a></button>


        </form>


        <script>
        $(document).ready(function() {
            $('#username').on('input', function() {
                $(this).val($(this).val().replace(/[^a-zA-Z ç - . , / ]/g, ''));
            });
            // Aplicar máscara ao campo de senha
            $('#password').mask('000000');
        });
        </script>
    </body>

</html>