<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title> BD-Produtos</title>
    <link rel="stylesheet" type="text/css" href="../css/css.css">
    <link rel="stylesheet" type="text/css" href="../css/Menu.css">
    <link rel="stylesheet" type="text/css" href="../css/carossel.css">
    <link rel="stylesheet" type="text/css" href="../css/Sobre.css">
    <link href="https://fonts.googleapis.com/css?family=Chicle" rel="stylesheet">
</head>

<body>


    <header>
        <input type="checkbox" id="menu-bar">
        <label for="menu-bar">Menu</label>

        <div class="nav">

            <div class="menu">

                <nav>
                    <a href="login.php">Home</a>

                    <ul>

                        <li><a href="#">Cadastrar</a>
                            <ul>
                                <a href="login.php">Faça Login primeiro</a>

                            </ul>
                        </li>
                        </li>
                        <li><a href="#">Listar</a>

                            <ul>
                                <a href="login.php">Faça Login primeiro</a>

                            </ul>
                        </li>
                        </li>

                        <li><a href="#">Pesquisar</a>
                            <ul>
                                <a href="login.php">Faça Login primeiro</a>

                            </ul>
                        </li>
                        </li>
                        <li><a href="#">Excluir</a>

                            <ul>
                                <a href="login.php">Faça Login primeiro</a>

                            </ul>
                        </li>
                        </li>
                        <li><a href="#">Alterar</a>

                            <ul>
                                <a href="login.php">Faça Login primeiro</a>

                            </ul>
                        </li>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
    </header>

    <div class="pic-ctn">
        <img src="https://i.pinimg.com/originals/3c/7a/fc/3c7afc1b68c0f8cc367dd9d0f1f383de.jpg?t=1" alt="" class="pic">
        <img src="https://images3.alphacoders.com/132/1322308.jpeg?t=2" alt="" class="pic">
        <img src="https://cdn.wallpapersafari.com/70/43/Pu3aLo.jpg?t=3" alt="" class="pic">
        <img src="https://images3.alphacoders.com/132/1329414.png?t=4" alt="" class="pic">
        <img src="https://wallpaper-house.com/data/out/9/wallpaper2you_358925.jpg?t=5" alt="" class="pic">
    </div>

    <div class="container">
        <div class="card">
            <div class="content">
                <h2>01</h2>
                <h3>Cadastrar </h3>
                <p>Cadastre seus produtos aqui!</p>
                <a href="login.php">Faça Login primeiro</a>

            </div>
        </div>
        <div class="card">
            <div class="content">
                <h2>02</h2>
                <h3>Listar</h3>
                <p> Veja seus produtos aqui!</p>
                <a href="login.php">Faça Login primeiro</a>


            </div>
        </div>
        <div class="card">
            <div class="content">
                <h2>03</h2>
                <h3>Pesquisar</h3>
                <p>Pesquise seus produtos aqui!</p>
                <a href="login.php">Faça Login primeiro</a>

            </div>
        </div>

        <div class="card">
            <div class="content">
                <h2>04</h2>
                <h3>Excluir</h3>
                <p>Excluir seus produtos</p>
                <a href="login.php">Faça Login primeiro</a>


            </div>
        </div>
        <div class="card">
            <div class="content">
                <h2>05</h2>
                <h3>Alterar</h3>
                <p>Altere seus Produtos aqui!</p>
                <a href="login.php">Faça Login primeiro</a>



            </div>
        </div>

        <h1 class="rev-block">
            <span>Etec Zona Leste</span>
        </h1>
        <h1 class="rev-block onemore">
            <span>realizado por:</span><br>
            <span>Danilo Santos Soares</span>
        </h1>

        <script type="text/javascript" src="vanilla-tilt.js"></script>
        <script>
        VanillaTilt.init(document.querySelectorAll(".card"), {
            max: 25,
            speed: 400,
            glare: true,
            "max-glare": 1,
        });
        </script>


</body>

</html>