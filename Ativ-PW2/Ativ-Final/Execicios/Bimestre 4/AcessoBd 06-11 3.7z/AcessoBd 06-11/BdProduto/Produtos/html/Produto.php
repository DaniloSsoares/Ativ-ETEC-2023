<?php


include_once 'conectar.php';

//parte 1 - atributos

error_reporting(E_ALL);
ini_set('display_errors', 1);

function Erro() {
    echo '<script>window.location.href = "erro.php";</script>';
    exit();
}

class Produto
{
    private $id;
    private $nome;
    private $estoque;
    private $conn;

    //parte 2 os getters e setter
    public function getId(){
        return $this->id;
    }
    public function setId($iid){
        $this->id = $iid;
    }

    public function getNome(){
        return $this->nome;
    }
    public function setNome($name){
    $this->nome= $name;
    }
    public function getEstoque(){
        return $this->estoque;
    }
       public function setEstoque($estoqui){
        $this->estoque=$estoqui;
    }

function listar()
{
    try{

        $this->conn = new conectar();
        $sql = $this->conn->query("select * from produtos order by id");
        $sql -> execute();
        return $sql->fetchAll();
        $this->conn = null;
    }
    catch(PDOException $exc)
    {
        echo "Erro ao executar consulta. " . $exc->getMessage();
    }
}

     //Parte Salvar
     function salvar()
     {
        try{
            $this->conn = new Conectar();
            $sql = $this->conn->prepare("insert into produtos values (null,?,?)");
            @$sql-> bindParam(1, $this->getNome(), PDO::PARAM_STR);
            @$sql-> bindParam(2, $this->getEstoque(), PDO::PARAM_STR);
            if($sql->execute() == 1)
            {
                return "Registro salvo com sucesso!";
            }
            $this->conn = null;
        }
        catch(PDOException $exc)
        {
            echo "Erro ao Salvar o registro." . $exc->getMessage();
        }
     }
     

     //Parte alterar
    
     function alterar(){
        try{
            $this-> conn = new Conectar();
            $sql = $this -> conn ->prepare("select * from produtos where id = ?"); //informe o ? (parametro)
            @$sql -> bindParam(1,$this->getId(),PDO::PARAM_STR);
            @$sql->execute();

            
               
            $result= $sql->fetchAll();
            $this ->conn = null;
            if (!$result) {
                // Se nenhum resultado for encontrado, retornar um array vazio
                header("Location: erro.php");
            } else {
                // Se houver resultados, retornar o array
                return $result;
            }
        } catch (PDOException $exc) {
            echo "Erro ao Executar Consulta.." . $exc->getMessage();
        }
        
    
    catch(PDOException $exc)
    {
        echo "Erro ao alterar." . $exc->getMessage();
    }
 }
     function alterar2(){
        try{
        $this-> conn = new Conectar();
        $sql = $this -> conn ->prepare("update produtos set nome = ?, estoque = ? where id = ?");
        @$sql -> bindParam(1,$this->getNome(),PDO::PARAM_STR);
        @$sql->bindParam(2, $this->getEstoque(),PDO::PARAM_STR);
        @$sql->bindParam(3, $this->getId(),PDO::PARAM_STR);
        if($sql->execute()==1)
        {
            return "Registro alterado com sucesso!";
        }
        $this->conn = null;
    }
    catch(PDOException $exc)
    {
        echo "Erro ao Salvar o registro." . $exc->getMessage();
    }
 }

 function consultar()
 {
    try{
        $this-> conn = new Conectar();
        $sql = $this -> conn ->prepare("select * from produtos where nome like ?"); //informe o ? (parametro)
        @$sql -> bindParam(1, $this->getNome(),PDO::PARAM_STR);
        //@$sql-> bindParam(1,$this->getNome()."%",PDO::PARAM_STR);
        
    @$sql->execute();

    $result=  $sql -> fetchAll();  
    if (!$result) {
      return "Nome não encontrado, tente novamente";
  }
  else{
      $this->conn = null;
      return $result;
  }
  

}
catch(PDOException $exc)
{
  echo "Erro ao Executar Consulta.." . $exc->getMessage();
}
}

 function exclusao()
 {
    try
    {
        $this-> conn = new Conectar();

        $sql = $this->conn->prepare("SELECT * FROM produtos WHERE id = ?");
        @$sql->bindParam(1, $this->getId(), PDO::PARAM_STR);
        $sql->execute();
       
        $result = $sql->fetch(PDO::FETCH_ASSOC);
       
        if (!$result) {
            
            Erro();
        }

        $sql = $this -> conn ->prepare("delete from produtos where id = ?"); //informe o ? (parametro)
        @$sql -> bindParam(1,$this->getId(),PDO::PARAM_STR);
        if($sql->execute() == 1)
        {
            return "Excluindo com sucesso! ";
        }
        else
        {
            return "Erro na exclusão !";
        }
    
            $this ->conn = null;
        }
    
    catch(PDOException $exc)
    {
        echo "Erro ao excluir" . $exc->getMessage();
    }
      }
        }