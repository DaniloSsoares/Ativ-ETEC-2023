<?php
include_once 'conectar.php';

class Usuario
{
    private $usu;
    private $senha;
    private $conn;

    public function getUsu(){
        return $this->usu;
    }
    public function setUsu($usuario){
$this->usu = $usuario;
    }
    public function getSenha(){
        return $this->senha;
}
public function setSenha($senha){
$this -> senha = $senha;
}

public function logar($login, $senha)
{
    try {
        $this->conn = new Conectar();
        $sql = $this->conn->prepare("select * from usuario WHERE Login LIKE ? AND Senha = ?");
        $sql->bindParam(1, $login, PDO::PARAM_STR);
        $sql->bindParam(2, $senha, PDO::PARAM_STR);
        
        $sql->execute();
        $result = $sql->fetchAll(); 
        $this->conn = null;
        
        if(count($result) > 0) {
            return true; // Encontrou correspondência no banco de dados
        } else {
            return false; // Não encontrou correspondência no banco de dados
        }

    } catch(PDOException $exc) {
        echo "<span class='text-green-200'>Erro ao executar consulta.</span>" . $exc->getMessage();
        return false; // Erro ao executar consulta
    }
}
}
?>