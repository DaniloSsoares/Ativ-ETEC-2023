<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Erro</title>
    <link rel="stylesheet" type="text/css" href="../css/erro.css">
    <link rel="stylesheet" type="text/css" href="../css/Menu.css">
    <title>Cadastrar</title>
</head>

<body>
    <header>
        <input type="checkbox" id="menu-bar">
        <label for="menu-bar">Menu</label>

        <div class="nav">

            <div class="menu">

                <nav>
                    <a href="login.php" class="logo">Home</a>

                    <ul>

                        <li><a href="#">Cadastrar</a>
                            <ul>
                                <a href="login.php">Voltar para o login</a>
                            </ul>
                        </li>
                        <li><a href="#">Listar</a>

                            <ul>
                                <a href="login.php">Voltar para o login</a>
                            </ul>
                        </li>
                        </li>

                        <li><a href="#">Pesquisar</a>
                            <ul>
                                <a href="login.php">Voltar para o login</a>
                            </ul>
                        </li>
                        </li>
                        <li><a href="#">Excluir</a>

                            <ul>
                                <a href="login.php">Voltar para o login</a>
                            </ul>
                        </li>
                        </li>
                        <li><a href="#">Altetar</a>

                            <ul>
                                <a href="login.php">Voltar para o login</a>
                            </ul>
                        </li>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
    </header>

    <div class="erro">
        <div class="box">
            <span></span>
            <div class="content">
                <h2>Erro</h2>
                <p>Erro ao logar volte para o login</p>
                <a href="login.php">Voltar para o login</a>
            </div>
        </div>
</body>

</html>